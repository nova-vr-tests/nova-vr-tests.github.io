Created by Herminio Nieves @2015
 for non comercial use.Please do not
resale or bundle with any other product
for sales purposes,some people like to take
other peoples work and put it for sale without 
concent.Have fun with this model and do wonderfull
renders.
Visit hns3d.com for more fantastic models

just give the apropiate credits!
non movable parts.

Jesus Saves!